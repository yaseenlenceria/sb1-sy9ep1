import VideoDownloader from '@/components/VideoDownloader';
import HomeFeatures from '@/components/HomeFeatures';
import HowToDownload from '@/components/HowToDownload';
import { Metadata } from 'next';
import { Download, Share2, Video } from 'lucide-react';

export const metadata: Metadata = {
  title: 'TikTok Video Downloader - Download TikTok Videos Without Watermark',
  description: 'Free online TikTok video downloader. Download TikTok videos without watermark in HD quality. Fast, simple, and secure.',
  keywords: 'tiktok downloader, tiktok video download, download tiktok without watermark, tiktok video downloader online, tiktok app, tiktok download video song',
};

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
            TikTok Video Downloader
          </h1>
          <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
            Download TikTok videos without watermark in HD quality. Fast, simple, and secure.
          </p>
        </div>

        <VideoDownloader />

        <HowToDownload />
        
        <HomeFeatures />

        <div className="mt-20 prose prose-lg max-w-none">
          <h2 className="text-3xl font-bold text-center mb-8">
            About Our TikTok Downloader
          </h2>
          <div className="bg-white rounded-2xl shadow-sm p-8">
            <p className="text-gray-600 mb-6">
              SaveDownloadTT is a free TikTok video downloader that helps you download TikTok videos without watermark online. 
              Save videos in the highest quality MP4 format and HD resolution.
            </p>

            <h3 className="text-2xl font-semibold mt-8 mb-4">Features of Our TikTok Downloader</h3>
            <ul className="list-disc pl-6 text-gray-600 space-y-2">
              <li>Fast Downloads Without Interruption - Download HD TikTok videos in less than five seconds</li>
              <li>100% Free and Easy to Use - No registration required</li>
              <li>TikTok Downloader With No Watermark - Save videos without the TikTok logo</li>
              <li>MP3/MP4 Formats - Convert TikTok videos into MP4 and MP3 formats</li>
              <li>High-quality Downloads - Download in original quality</li>
              <li>Compatible with Multiple Devices - Works on all devices with browsers</li>
              <li>Safe TikTok Saver - SSL certified and virus-free</li>
            </ul>

            <h3 className="text-2xl font-semibold mt-8 mb-4">Why Choose Our Service?</h3>
            <p className="text-gray-600 mb-6">
              Our TikTok downloader offers a seamless experience for saving your favorite TikTok content. 
              Whether you're a content creator looking to repurpose videos or a viewer wanting to save memorable content, 
              our tool provides fast, reliable, and high-quality downloads without compromising on security or ease of use.
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}