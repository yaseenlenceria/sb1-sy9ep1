'use client';

import { Progress } from "@/components/ui/progress";
import { useState, useEffect } from 'react';

interface DownloadProgressProps {
  isDownloading: boolean;
  onComplete?: () => void;
}

export default function DownloadProgress({ isDownloading, onComplete }: DownloadProgressProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (isDownloading) {
      setProgress(0);
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            onComplete?.();
            return 100;
          }
          return prev + 2;
        });
      }, 50);

      return () => clearInterval(interval);
    }
  }, [isDownloading, onComplete]);

  if (!isDownloading) return null;

  return (
    <div className="w-full space-y-2">
      <Progress value={progress} className="h-2" />
      <p className="text-sm text-center text-gray-600">
        Downloading... {progress.toFixed(0)}%
      </p>
    </div>
  );
}