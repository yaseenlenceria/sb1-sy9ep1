'use client';

import { useState } from 'react';
import { analyzeTikTokVideo, type TikTokResponse } from '@/lib/api';
import { Loader2, Download, Link2, AlertCircle } from 'lucide-react';
import Image from 'next/image';
import { formatFileSize } from '@/lib/utils';
import { Progress } from './ui/progress';

export default function VideoDownloader() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TikTokResponse['data'] | null>(null);
  const [error, setError] = useState('');
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);

  const handleUrlChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setUrl(value);
    
    if (value.includes('tiktok.com')) {
      try {
        setLoading(true);
        setError('');
        const data = await analyzeTikTokVideo(value);
        if (data.code === 0 && data.data) {
          setResult(data.data);
        } else {
          throw new Error(data.msg || 'Failed to analyze video');
        }
      } catch (err: any) {
        setError(err.message || 'Failed to analyze video. Please try again.');
        setResult(null);
      } finally {
        setLoading(false);
      }
    } else {
      setResult(null);
    }
  };

  const handleDownload = async (videoUrl: string, watermark: boolean = false) => {
    try {
      setIsDownloading(true);
      setDownloadProgress(0);

      const response = await fetch(videoUrl);
      if (!response.ok) throw new Error('Download failed');
      
      const reader = response.body?.getReader();
      const contentLength = +(response.headers.get('Content-Length') ?? 0);
      
      if (!reader) throw new Error('Failed to initialize download');

      const chunks: Uint8Array[] = [];
      let receivedLength = 0;

      while (true) {
        const { done, value } = await reader.read();
        
        if (done) break;
        
        chunks.push(value);
        receivedLength += value.length;
        
        const progress = (receivedLength / contentLength) * 100;
        setDownloadProgress(progress);
      }

      const blob = new Blob(chunks);
      const downloadUrl = window.URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `tiktok-video${watermark ? '-with-watermark' : ''}.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      setError('Failed to download video. Please try again.');
    } finally {
      setIsDownloading(false);
      setDownloadProgress(0);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-4">
      <div className="space-y-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
            <Link2 className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="url"
            value={url}
            onChange={handleUrlChange}
            placeholder="Paste TikTok video URL here..."
            className="w-full pl-10 pr-10 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
            disabled={loading || isDownloading}
          />
          {loading && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              <Loader2 className="animate-spin h-5 w-5 text-blue-500" />
            </div>
          )}
        </div>

        {error && (
          <div className="bg-red-50 text-red-500 p-3 rounded-xl flex items-start space-x-3">
            <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {result && (
          <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
            <div className="preview-container">
              {result.cover && (
                <Image
                  src={result.cover}
                  alt={result.title || 'TikTok video thumbnail'}
                  fill
                  className="object-cover"
                  unoptimized
                  priority
                />
              )}
            </div>
            <div className="p-4 space-y-3">
              <h2 className="text-lg font-semibold line-clamp-2">{result.title}</h2>
              {result.author && (
                <div className="flex items-center space-x-3">
                  {result.author.avatar && (
                    <Image
                      src={result.author.avatar}
                      alt={result.author.nickname || 'Author avatar'}
                      width={32}
                      height={32}
                      className="rounded-full border border-gray-200"
                      unoptimized
                    />
                  )}
                  <span className="font-medium text-gray-700 text-sm">{result.author.nickname}</span>
                </div>
              )}

              {isDownloading && (
                <div className="space-y-2">
                  <Progress value={downloadProgress} className="h-1.5" />
                  <p className="text-xs text-center text-gray-600">
                    Downloading... {downloadProgress.toFixed(1)}%
                  </p>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => handleDownload(result.play)}
                  disabled={isDownloading}
                  className="flex-1 flex items-center justify-center px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                >
                  {isDownloading ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <Download className="w-4 h-4 mr-2" />
                  )}
                  Without Watermark
                  <span className="text-xs ml-2">({formatFileSize(result.size)})</span>
                </button>
                <button
                  onClick={() => handleDownload(result.wmplay, true)}
                  disabled={isDownloading}
                  className="flex-1 flex items-center justify-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                >
                  {isDownloading ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <Download className="w-4 h-4 mr-2" />
                  )}
                  With Watermark
                  <span className="text-xs ml-2">({formatFileSize(result.wm_size)})</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}