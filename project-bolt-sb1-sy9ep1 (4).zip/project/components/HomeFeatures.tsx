'use client';

import { Download, Zap, Monitor, Shield, Music, Video } from 'lucide-react';

const features = [
  {
    icon: Download,
    title: "High Quality Downloads",
    description: "Download videos in HD quality without any quality loss"
  },
  {
    icon: Zap,
    title: "Fast & Free",
    description: "Unlimited downloads at high speed, completely free"
  },
  {
    icon: Monitor,
    title: "All Devices",
    description: "Works perfectly on mobile, tablet, and desktop"
  },
  {
    icon: Shield,
    title: "Safe & Secure",
    description: "No registration required, SSL encrypted downloads"
  },
  {
    icon: Music,
    title: "MP3 Extraction",
    description: "Extract audio from TikTok videos in MP3 format"
  },
  {
    icon: Video,
    title: "No Watermark",
    description: "Remove TikTok watermark from downloaded videos"
  }
];

export default function HomeFeatures() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">
            Why Choose Our TikTok Downloader?
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            The fastest and most reliable way to download TikTok videos
          </p>
        </div>

        <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 text-blue-600 mb-4">
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}