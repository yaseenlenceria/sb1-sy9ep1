'use client';

import { Copy, Download, Share2 } from 'lucide-react';

const steps = [
  {
    icon: Share2,
    title: "Find a TikTok",
    description: "Play the video you'd like to save using the TikTok app"
  },
  {
    icon: Copy,
    title: "Copy the link",
    description: "Tap 'Share' and then tap 'Copy link'"
  },
  {
    icon: Download,
    title: "Save TikTok",
    description: "Paste the link above and click the download button"
  }
];

export default function HowToDownload() {
  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">
            How to Download TikTok Videos
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Download any TikTok video in three simple steps
          </p>
        </div>

        <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-3">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative"
            >
              <div className="flex flex-col items-center">
                <div className="flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 text-blue-600 mb-4">
                  <step.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-center text-gray-600">
                  {step.description}
                </p>
              </div>
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gray-200 -translate-y-1/2" />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}